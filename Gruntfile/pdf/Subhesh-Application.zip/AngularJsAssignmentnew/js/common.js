$(document).ready(function(){
    
    /*Toggle Animation for menu*/
    
    $('.collapse-icon').on('click', function(){
        $(this).toggleClass('collapsed');
        $('#nav-collapse').slideToggle();
    });
    $('.collapse ul li a').on('click', function(){
        $('.collapse ul li a').removeClass('active');
        $(this).addClass('active');
    });
    
    /*Active Class Query*/
    
    var url = window.location.href;
	url = url.split('/').reverse()[0];
    $('nav ul li a[href="#!/'+url+'"]').addClass('active');    
    
});

/*Fix for browser resize*/

function resizeFunction(){
    if(window.outerWidth >= 768){
        document.getElementById("nav-collapse").style.display = "block";
    }
    if(window.outerWidth < 767){
        document.getElementById("nav-collapse").style.display = "none";
    }
}