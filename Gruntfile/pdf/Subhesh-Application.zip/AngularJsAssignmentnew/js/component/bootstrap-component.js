angular.
    module('bootstrap').
    component('bootstrap', {
        templateUrl: 'template/bootstrap.html',
    
        controller:[function bootController() {
            
           }
        ]
    });