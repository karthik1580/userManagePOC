angular.
  module('phoneDetail').
  component('phoneDetail', {
    templateUrl: 'template/detail.template.html',
    controller: ['$http', '$routeParams', '$scope','$sce',
      function PhoneDetailController($http, $routeParams, $scope, $sce) {
        var self = this;
        self.setImage = function setImage(imageUrl) {
          self.mainImageUrl = imageUrl;
        };
          
        $http.get('json/phones/' + $routeParams.phoneId + '.json').then(function(response) {
            self.phone = response.data;
            $scope.url =  $sce.trustAsResourceUrl(self.phone.youtubevid);
            self.setImage(self.phone.images[0]);
        
        });
      }
    ]
  });