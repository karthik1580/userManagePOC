angular.
    module('phoneList').
    component('phoneList', {
        templateUrl: 'template/list-template.html',
    
        controller:['$http', function PhoneListController($http) {
            var self = this;
            
            self.sort = 'age';
            
            $http.get('json/phone-list.json').then(function(response){
                 self.phones = response.data;                               
            });
           }
        ]
    });