angular.module('phonecatApp', [
    'ngRoute',
    'bootstrap',
    'phoneList',
    'phoneDetail',
    'core',
    'ngAnimate'
]);