var app = angular.module("sampleApplication",['ngRoute','ui.grid', 'ui.grid.edit','ui.grid.selection','ui.grid.rowEdit', 'ui.grid.cellNav']);
app.controller("sampleController",function(){
	this.sampleText = "Praise the LORD its Working";
});

app.config(['$routeProvider', function($routeProvider) {
 $routeProvider
   .when('/workspace', {
    templateUrl: '/app/pages/cobasOpenChannel/cobasOpenChannel.html',
    controller: 'cobasOpenChannelController'
  })
  .when('/eBarcodemanager', {
    templateUrl: '/app/pages/eBarcodemanager/eBarcodemanager.html',
    controller: 'eBarcodeCtrl'
  })
  .when('/userConfiguration', {
    templateUrl: '/app/pages/userConfiguration/userConfiguration.html',
    controller: 'userConfigurationController'
  })
  .otherwise({
    redirectTo: '/workspace'
  });
}]);