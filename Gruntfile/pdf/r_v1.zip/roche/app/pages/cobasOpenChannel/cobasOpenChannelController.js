app.controller("cobasOpenChannelController",function(){
	var vm = this;	
		//vm.tabName = "Cobas Open Channel";
      	vm.cobasuserchannel = [
			{ 
				cobasname: "t 511", 
				cobasimageurl: "app/images/coabas.jpg",
				cobasgraph:[
					{
						cobastype : "Application", 
						pollvalue: "25",
						endpoint: "50"
					},{
						cobastype : "Container", 
						pollvalue: "150",
						endpoint: "200"
					},{
						cobastype : "Container", 
						pollvalue: "80",
						endpoint: "100"
					}
				]
			},
			{ 
				cobasname: "t 711", 
				cobasimageurl: "app/images/coabas.jpg",
				cobasgraph:[
					{
						cobastype : "Application", 
						pollvalue: "30",
						endpoint: "50"
					},{
						cobastype : "Container", 
						pollvalue: "50",
						endpoint: "200"
					},{
						cobastype : "Container", 
						pollvalue: "80",
						endpoint: "100"
					}
				]
			},
			{ 
				cobasname: "e 601", 
				cobasimageurl: "app/images/coabas.jpg",
				cobasgraph:[
					{
						cobastype : "Application", 
						pollvalue: "20",
						endpoint: "50"
					},{
						cobastype : "Container", 
						pollvalue: "60",
						endpoint: "200"
					},{
						cobastype : "Container", 
						pollvalue: "25",
						endpoint: "100"
					}
				]
			},
			{ 
				cobasname: "c xxx", 
				cobasimageurl: "app/images/coabas.jpg",
				cobasgraph:[
					{
						cobastype : "Application", 
						pollvalue: "100",
						endpoint: "50"
					},{
						cobastype : "Container", 
						pollvalue: "10",
						endpoint: "200"
					},{
						cobastype : "Container", 
						pollvalue: "100",
						endpoint: "100"
					}
				]
			}

        ];
		
});