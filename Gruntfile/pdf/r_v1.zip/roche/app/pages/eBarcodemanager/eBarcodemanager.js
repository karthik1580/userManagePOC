app.controller("eBarcodeCtrl",function(){
	this.tabName = "Home Tab";
});