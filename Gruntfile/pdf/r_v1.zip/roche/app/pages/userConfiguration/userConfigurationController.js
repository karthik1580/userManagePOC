app.controller("userConfigurationController", ['workSpaceService', '$scope', '$q', function(workSpaceService, $scope, $q) {
    $scope.tabName = "User Configuration";
    $scope.myData = [{
            "primaryAccount": "Lab ABC",
            "workSpace": "t511",
            "serialNumber": "83929",
            "acn": '5'
        },
        {
            "primaryAccount": "Lab TTT",
            "workSpace": "t711",
            "serialNumber": "920482",
            "acn": '5'
        },
        {
            "primaryAccount": "Lab XYZ",
            "workSpace": "t511",
            "serialNumber": "836483",
            "acn": '20'
        },
        {
            "primaryAccount": "Lab JJJ",
            "workSpace": "t711",
            "serialNumber": "39895",
            "acn": '10'
        }
    ];
    $scope.gridOptions = {
        enableRowSelection: true,
        enableSelectAll: true,
        selectionRowHeaderWidth: 35,
        rowHeight: 35,
        showGridFooter: true
    };
    $scope.workSpaceList = _.uniq(_.pluck($scope.myData, "workSpace"));
    workSpaceService.setWorkSpaceList($scope.workSpaceList);
    $scope.workSpaces = _.map($scope.workSpaceList, function(val, index, array) {

        return {
            'id': val,
            'workSpace': val
        };
    });
    console.log(this.workSpaces);
    $scope.gridOptions.columnDefs = [{
            name: "",
            field: "fake",
            cellTemplate: '<div class="ui-grid-cell-contents" >' +
                '<button value="Edit" ng-if="!row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.enterEditMode($event)">Delete</button>' +
                '<button value="Edit" ng-if="!row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.enterEditMode($event)">Edit</button>' +
                '<button value="Edit" ng-if="row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.saveEdit($event)">Update</button>' +
                '<button value="Edit" ng-if="row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.cancelEdit($event)">Cancel</button>' +
                '</div>',
            width: '30%',
            enableCellEdit: false,
            enableFiltering: false,
            enableSorting: false,
            showSortMenu: false,
            enableColumnMenu: false,
        },

        {
            name: 'primaryAccount',
            displayName: 'Primary Acoount',
            width: '25%',
            enableCellEdit: true
        },
        {
            name: 'workSpace',
            displayName: 'Work Space',
            editableCellTemplate: 'ui-grid/dropdownEditor',
            width: '10%',
            cellFilter: 'workSpaceFilter',
            editDropdownValueLabel: 'workSpace',
            editDropdownOptionsArray: $scope.workSpaces
        },
        {
            name: 'serialNumber',
            displayName: 'Serial number',
            width: '25%'
        },
        {
            name: 'acn',
            displayName: 'ACN',
            width: '10%'
        }
    ];
    $scope.gridOptions.data = $scope.myData;

    $scope.saveRow = function(rowEntity) {
        // create a fake promise - normally you'd use the promise returned by $http or $resource
        //Get all selected rows
        var selectedRows = $scope.gridApi.selection.getSelectedRows();
        //var rowCol = $scope.gridApi.cellNav.getFocusedCell().col.colDef.name;
        var promise = $q.defer();
        $scope.gridApi.rowEdit.setSavePromise(rowEntity, promise.promise);
        setTimeout(function() {
            promise.resolve();
        }, 3000);
    };



    $scope.info = {};
    $scope.gridOptions.onRegisterApi = function(gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;
        gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
        gridApi.edit.on.afterCellEdit($scope, function(rowEntity, colDef, newValue, oldValue) {
            var selectedRows = $scope.gridApi.selection.getSelectedRows();
            if (newValue != oldValue) {
                rowEntity.state = "Changed";
                //Get column
                var rowCol = $scope.gridApi.cellNav.getFocusedCell().col.colDef.name;
                angular.forEach(selectedRows, function(item) {
                    item[rowCol] = rowEntity[rowCol]; // $scope.convertDate(rowEntity[rowCol]);
                    item.state = "Changed";
                    item.isDirty = false;
                    item.isError = false;
                });
            }
        });
    }
}]);
app.service('workSpaceService', function() {
    this.workSpaceList = [];
    var self = this;
    this.setWorkSpaceList = function(workSpaceList) {
        self.workSpaceList = workSpaceList;
    }
    this.getWorkSpaceList = function(workSpaceList) {
        return self.workSpaceList;
    }
})
app.filter('workSpaceFilter', function(workSpaceService) {
    var workSpaceHash = {};
    this.workSpaceList = workSpaceService.getWorkSpaceList(_.pluck(this.myData, "workSpace"));
    for (var i = 0; i < this.workSpaceList.length; i++) {
        workSpaceHash[this.workSpaceList[i]] = this.workSpaceList[i]
    }
    console.log(workSpaceHash);
    return function(input) {
        if (!input) {
            return '';
        } else {
            return workSpaceHash[input];
        }
    };
})