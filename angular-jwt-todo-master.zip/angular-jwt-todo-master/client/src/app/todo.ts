export class Todo {
  id: number;
  user_id: number;
  name: string;
  completed: boolean;
}
