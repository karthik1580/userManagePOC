# Todoapp

## API server

Run `node app.js` for the API server. Navigate to `http://localhost:4000` to test if the API server is active.

